# fracmechfactors
This is a package to extract the Non-dimensional factors of fracture mechanics. 
